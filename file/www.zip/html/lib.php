<?php
function is_logged()
{
    if (isset($_SESSION['name'])) {

        return true;
    }
    return false;
}

function is_valid_name($name)
{
    if (!is_string($name)) {
        return false;
    }
    return preg_match('/\A[0-9A-Z]{4,64}\z/i', $name);
}

function set_user($name)
{
    $_SESSION['name'] = $name;
}

function redirect($path)
{
    header('Location: ' . $path);
    exit();
}

function get_user()
{
    return $_SESSION['name'];
}

function check_session($session)
{
    foreach ($session as $keys => $values) {
        foreach ($values as $key => $value) {
            if ($key === 'admin' && $value === 1) {
                return true;
            }
        }
    }
    return false;
}

