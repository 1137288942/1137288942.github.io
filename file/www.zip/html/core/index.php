<?php
require_once('./init.php');
error_reporting(0);
if (check_session($_SESSION)) {
    #变成管理员吧，奥利给
} else {
    die('只有管理员才能看到我哟');
}

