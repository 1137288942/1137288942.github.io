<?php
require_once 'init.php';
class User
{
    #登录
    public function login($name)
    {
        if (is_logged()) {
            redirect('/?page=upload');
        }
        if (is_valid_name($name)) {
            set_user($name);
        } else {
            redirect('/?page=index');
        }
    }
}
if (is_logged()) {
    redirect('./?page=index');
}

if (isset($_POST['name'])) {
    $name = $_POST['name'];
    $user = new User();
    $user->login($name);
    redirect('/?page=index');
}



