<?php
if(is_logged()){?>
<p>欢迎<?php echo $_SESSION['name']; ?> </p>
<br><br>
<p>快去设置签名吧 </p>
<?php } else {redirect('/?page=login');} ?>