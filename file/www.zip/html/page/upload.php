<html>
<?php if(is_logged())include("./upload_sign.php"); else redirect('/?page=index'); ?>
<form action="" method="post" enctype="multipart/form-data">
    <br><br>
    请输入签名：<input type="text" name="sign">
    <input type="submit" value="提交">
</form>
</html>
<?php 
if (isset($_POST['sign'])){
	echo "签名修改完成，快去查看吧";
}
?>