<?php
require_once 'init.php';


if (!isset($_GET['page']) || empty($_GET['page'])) {
    $page = 'home';
} else {
    $page = $_GET['page'];
}

if (in_array($page, ['profile',], true) && !is_logged()) {
    redirect('/?page=index');
}
if (in_array($page, ['upload', 'index', 'login','profile'], true)) {
    include('include/header.php');
    include('page/' . $page . '.php');
    include('include/footer.php');
} else {
    redirect('/?page=index');
}
?>


