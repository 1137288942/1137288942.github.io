<?php
require_once('init.php');

class upload_sign
{
    public $sign;
    public $admin = 0;

    public function __construct()
    {
        if (isset($_POST['sign'])) {
            $this->sign = $_POST['sign'];
        } else {
            $this->sign = "这里空空如也哦";
        }
    }

    public function upload()
    {
        if ($this->checksign($this->sign)) {
            $_SESSION['sign'] = $this->sign;
            $_SESSION['admin'] = $this->admin;
        } else {
            echo "???";
        }
    }

    public function checksign($sign)
    {
        return true;
    }
}

$a = new upload_sign();
$a->upload();


